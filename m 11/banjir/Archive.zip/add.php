<?php
   	include("connection.php");
   	
   	//$link=Connection();
   date_default_timezone_set("Asia/Kuala_Lumpur");
   $temp1=$_GET["temp1"];
	$hum1=$_GET["hum1"];
   echo $temp1. " & ". $hum1;
	$query = "INSERT INTO tbl_log (temp, rh) VALUES ('$temp1','$hum1')"; 
   	
   if  ((is_null($temp1) or is_null($hum1)))
   {
      //echo "Ada yang kosong";
   }
   else
   {
      mysqli_query($conn,$query);
      
   }
   header("Location: index.php");
?>
