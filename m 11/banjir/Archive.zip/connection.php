<?php
$servernya="localhost";	//Nama Servernya dimasukkin kesini
$user=""; 		//Nama user MySQL
$auth_pass="";	//Password MySQL
$dbnya="";		//NamaDB nya

//mysqli_connect($servernya,$user,$auth_pass);
//mysqli_select_db($dbnya);

// Create connection
$conn = mysqli_connect($servernya, $user, $auth_pass, $dbnya);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

?>